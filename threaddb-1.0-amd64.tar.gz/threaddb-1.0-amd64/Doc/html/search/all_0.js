var searchData=
[
  ['database_0',['database',['../classtdb_1_1database.html',1,'tdb::database'],['../classtdb_1_1database.html#a39df45c0529c90f57faf5484bbb0b721',1,'tdb::database::database(size_t PackageSize_p, size_t PackageCacheLimit_p)'],['../classtdb_1_1database.html#a8e65f53bb47961586734230a127f59f9',1,'tdb::database::database(const std::string &amp;rIndexFileUTF8_p, size_t PackageCacheLimit_p)']]],
  ['dllexport_5f_1',['DLLEXPORT_',['../threaddb_types_8h.html#a0f476ab485de23c7986b382b68208f36',1,'threaddbTypes.h']]]
];
