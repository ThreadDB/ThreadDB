var searchData=
[
  ['newpackage_84',['NewPackage',['../classtdb_1_1database.html#afb8194c7f6adb5c84400f38b4d5bf2b0',1,'tdb::database']]],
  ['newthread_85',['NewThread',['../classtdb_1_1database.html#a0fe2e60aed371345377659165efe4c18',1,'tdb::database']]]
];
