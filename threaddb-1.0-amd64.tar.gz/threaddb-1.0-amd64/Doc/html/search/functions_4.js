var searchData=
[
  ['open_87',['Open',['../classtdb_1_1database.html#a0cddfa0ac7bc8f22fc23a225ff48f426',1,'tdb::database']]]
];
