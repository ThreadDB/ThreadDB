var searchData=
[
  ['readinfo_87',['ReadInfo',['../classtdb_1_1_read_info.html#a87249d846630eb0f1dc8a84536efc957',1,'tdb::ReadInfo']]],
  ['recover_88',['Recover',['../classtdb_1_1database.html#a3f45610e95916c739a6866efed6fb12d',1,'tdb::database::Recover(size_t Size_p, char pData_p[], tdb::ReadInfo &amp;rReadInfo_p)'],['../classtdb_1_1database.html#a75547978b51f7338f16f17489a75d73f',1,'tdb::database::Recover(size_t Size_p, char pData_p[], const threadDB_ItemInfo &amp;rItemHandle_p)']]],
  ['relocatefileto_89',['RelocateFileTo',['../classtdb_1_1database.html#a0faddc274b5d1463e9c11d06f5748eb6',1,'tdb::database']]],
  ['replace_90',['Replace',['../classtdb_1_1database.html#a96019307e736702033b9212623f04474',1,'tdb::database']]]
];
