var searchData=
[
  ['save_91',['Save',['../classtdb_1_1database.html#a12f5eca6579dbbaea37856df5784272f',1,'tdb::database']]],
  ['store_92',['Store',['../classtdb_1_1database.html#a8c187cad9141d4304f3cbefdb11c9d80',1,'tdb::database']]],
  ['synchronize_93',['Synchronize',['../classtdb_1_1database.html#ada2b4df535568570bdf888a4adcecad9',1,'tdb::database']]]
];
