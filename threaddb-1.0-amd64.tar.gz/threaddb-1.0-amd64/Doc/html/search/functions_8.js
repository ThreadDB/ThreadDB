var searchData=
[
  ['_7edatabase_116',['~database',['../classtdb_1_1database.html#a6134e83c49af8b649175290f86da0321',1,'tdb::database']]],
  ['_7ereadinfo_117',['~ReadInfo',['../classtdb_1_1_read_info.html#a7a1298b7a765585106b5236b8b528f47',1,'tdb::ReadInfo']]]
];
