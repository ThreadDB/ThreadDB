var searchData=
[
  ['database_18',['database',['../classtdb_1_1database.html',1,'tdb::database'],['../classtdb_1_1database.html#ab93ace191b5d9f88eea6a17773b9ac62',1,'tdb::database::database(size_t PackageSize_p=4096, size_t PackageCacheLimit_p=std::numeric_limits&lt; size_t &gt;::max(), const std::string &amp;rPackagesPath_p=&quot;&quot;)'],['../classtdb_1_1database.html#a6559b6162e4e35512ed129da143c5b3a',1,'tdb::database::database(const std::string &amp;rIndexFileUTF8_p, size_t PackageCacheLimit_p=std::numeric_limits&lt; size_t &gt;::max())']]],
  ['deref_19',['deref',['../classtdb_1_1ritem.html#ad550be19dc33725860f18cce3350654d',1,'tdb::ritem']]],
  ['dimension_20',['dimension',['../structtdb_1_1_point.html#ae9deb5eea429ab607823235f754856a2',1,'tdb::Point']]],
  ['dllexport_5f_21',['DLLEXPORT_',['../threaddb_types_8h.html#a0f476ab485de23c7986b382b68208f36',1,'threaddbTypes.h']]]
];
