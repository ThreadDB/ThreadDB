var searchData=
[
  ['key_42',['key',['../classtdb_1_1key.html',1,'tdb::key&lt; T &gt;'],['../classtdb_1_1key.html#aa0f4ae01b5000897314548b55d745b18',1,'tdb::key::key()']]]
];
