var searchData=
[
  ['y_360',['y',['../structtdb_1_1_point.html#a307c315bd4ecfd5d7437b56ef1eb06d9',1,'tdb::Point::y() const'],['../structtdb_1_1_point.html#a705e9a742d191bede8166ec757f563b5',1,'tdb::Point::y()']]]
];
