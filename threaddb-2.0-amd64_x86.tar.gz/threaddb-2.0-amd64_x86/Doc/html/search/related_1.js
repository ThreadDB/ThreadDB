var searchData=
[
  ['rgrid_3c_20t_2c_20c_2c_20d_2c_20l_20_3e_430',['rgrid&lt; T, C, D, L &gt;',['../classtdb_1_1rgrid__.html#aab8e36eeb510366fd38a7ceda123b8b1',1,'tdb::rgrid_']]],
  ['ritem_3c_20t_20_3e_431',['ritem&lt; T &gt;',['../classtdb_1_1pool.html#a51d4270e05ecfabf89b177bf7ba86d51',1,'tdb::pool']]]
];
