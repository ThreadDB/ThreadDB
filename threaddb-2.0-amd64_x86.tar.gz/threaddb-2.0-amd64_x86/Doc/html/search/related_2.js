var searchData=
[
  ['sitem_3c_20t_20_3e_432',['sitem&lt; T &gt;',['../classtdb_1_1pool.html#a4abdfd781c88c95b4b4471c523a25b57',1,'tdb::pool']]]
];
