var searchData=
[
  ['itemhandle_410',['ItemHandle',['../namespacetdb.html#ab3e07a82d0580b1b0ef1cc653bc461cb',1,'tdb']]]
];
