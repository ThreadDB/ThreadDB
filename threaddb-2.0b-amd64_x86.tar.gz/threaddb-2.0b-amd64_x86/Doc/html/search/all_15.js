var searchData=
[
  ['x_185',['x',['../structtdb_1_1_point.html#aefb1d6c22f125cfd8dccd66beaf0704b',1,'tdb::Point::x() const'],['../structtdb_1_1_point.html#ad5cd522aaa8b560049c556dfc15468ff',1,'tdb::Point::x()']]]
];
