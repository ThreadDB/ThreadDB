var searchData=
[
  ['array_5fdeleter_203',['array_deleter',['../structtdb_1_1array__deleter.html',1,'tdb']]]
];
