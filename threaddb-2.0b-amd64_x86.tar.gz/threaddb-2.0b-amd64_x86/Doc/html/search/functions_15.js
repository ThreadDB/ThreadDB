var searchData=
[
  ['z_359',['z',['../structtdb_1_1_point.html#a02158d563a0458c8528cd40a7228487b',1,'tdb::Point::z() const'],['../structtdb_1_1_point.html#ada8aa91c0701677e4e3b808e66e8f4b1',1,'tdb::Point::z()']]]
];
