var searchData=
[
  ['query_304',['query',['../classtdb_1_1rgrid__.html#a614701ece61e6792dc3d8a52c5b69541',1,'tdb::rgrid_::query()'],['../classtdb_1_1rgrid.html#ad188873aa1d3c37c0090b7d0563cbd4f',1,'tdb::rgrid::query()']]]
];
