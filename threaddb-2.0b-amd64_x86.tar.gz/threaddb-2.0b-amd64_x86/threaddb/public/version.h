/*
   Copyright (c) 2019 by The ThreadDB Project
   All Rights Reserved.

   ThreadDB undergoes the BSD License 2.0. You should have received a copy along with this program; if not, write to the ThreadDB Project.
   To obtain a full unlimited version contact thethreaddbproject(at)gmail.com.

   version.h - Version information
*/

#pragma once

#define TDB_MAJOR 1
#define TDB_MINOR 0
#define TDB_PATCH "168"
#define TDB_STATE "beta (unlicensed)"